# MacCrash
An app designed to stress test a mac, to see how much it can handle

#----Author----#
Author: ETCG
Website: https://etcg.github.io
Contact:
  - Email: epictincangames@gmail.com
  - Skype: flare.cat

#----Usage-----#
A simple double click should run it, but if you get a warning about it being from an unidentified developer (and therefore cannot open it), the following steps can get around that:
If you currently logged in as an Admin:
  1. Right click the app, and click "Open".
If you are logged in as standard user, and do not have admin privileges:
  1. Right click the app, and click "Show Package Contents".
  2. If it is not selected already, select the folder called "Contents".
  3. Hit Command + C to copy the folder.
  4. Make a new folder by opening a Finder window, navigating to an area you have access to (typically a good place is your Documents folder) and right click -> "New Folder".
  5. Name the folder MacCrash.app
  6. You will get a warning about naming it with the ".app" extension, click "Add".
  7. Right Click this new folder, and click "Show Package Contents".
  8. Hit Command + V to paste the needed files in this new folder.
  9. Hit the back button in the Finder window (top left) to go back one folder.
  10. Double click "MacCrash" and you are all set!
  ***This method of bypassing Apple's default security will work with any app you download***
NOTE: This app WILL crash any mac if run for long enough, which will slow down the computer a lot. The best way to stop this app is by restarting the computer, by holding down the power button for roughly 10 seconds, waiting 10 seconds, and then holding it down for 3 seconds.
NOTE: You won't get any response that it worked, but you will notice the change of speed after roughly 30 seconds
  
#----Notice----#
By using MacCrash, you agree that I do not take responsibility to(but not limited to):
-Any illegal actions you take using MacCrash
-Any damage done to any system from the use of MacCrash, whether it be yours or someone else's
-Any other trouble/issue/etc.
If you decide to distribute any part of MacCrash, this section MUST be included.
MacCrash was designed to stress test YOUR computer, and not someone else's.
In Summary: Use at your own risk.

#--Copyright--#
Copyright (c) 2016 ETCG

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.