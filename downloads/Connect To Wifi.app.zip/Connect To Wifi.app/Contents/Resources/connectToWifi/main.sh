#!/bin/sh
cd SpoofMAC
echo "Installing spoof-mac..."
python setup.py install
echo "Changing MAC Address..."
cd ..
spoof-mac.py randomize wi-fi
printf '%b' "\n\n\n\n"
echo "Done. If you cannot connect to the wifi in the next few minutes, please rerun this application."